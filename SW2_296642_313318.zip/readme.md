# Assigment SW2
Gilles Regamey 296642
Matieu Schertenleib 313318

## modified files
- all files in module/profile/verilog/*.v
- grayscale.c 
- project.files
- or1420SingleCore.v 

## additional note
While trying to debug the C program for the assignment that seemed to ignore any changes we made, we had the not so smart idea to load our program into flash. We soon realized that we probably overwrote the useful interface you gave us.
We have no idea how to directly write to the flash and we do not have the binaries for the serial interface, So we are stuck for now even tho the code was not assignment ready...
We are pretty sure the module is working as expected thanks to our testbench but we are still not sure if the program works with it.
