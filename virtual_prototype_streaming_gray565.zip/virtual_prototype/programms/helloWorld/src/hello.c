#include <stdio.h>
#include <vga.h>

int main () {
  vga_clear();
  printf("Hello World!\n" );
}
